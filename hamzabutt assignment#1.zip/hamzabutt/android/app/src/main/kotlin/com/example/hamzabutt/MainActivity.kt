package com.example.hamzabutt

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
